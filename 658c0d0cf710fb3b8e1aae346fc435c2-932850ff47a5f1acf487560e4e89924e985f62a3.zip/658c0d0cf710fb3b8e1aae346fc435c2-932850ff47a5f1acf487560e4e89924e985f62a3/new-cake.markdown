new cake
--------
A new birthday, a new cake.

-SVG
-CSS

based on: http://codepen.io/fixcl/pen/nKFDr

A [Pen](https://codepen.io/book-sim/pen/qEadgBq) by [book sim](https://codepen.io/book-sim) on [CodePen](https://codepen.io).

[License](https://codepen.io/license/pen/qEadgBq).